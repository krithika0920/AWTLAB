var express = require("express")
var path = require("path")

var app = new express()
app.use(express.urlencoded())
app.use(express.static("public"))

app.get("/",(req,response)=>{
    response.sendFile(path.join(__dirname,"index.html"))
})
app.get("/user/:id",(req,res)=>{
    res.write("user "+req.params.id+" fetched");
    res.end();
})
app.post("/signup",(req,res)=>{
    res.send("welcome "+req.body.uname)
})
app.get("/user",(req,res)=>{
    res.send("Get method")
})
app.listen(8001,()=>{
    console.log("server started successfully...")
})