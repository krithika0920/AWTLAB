var  express = require("express")
var app = new express()

app.get("/",function(req,res){
    res.write("First Get Request")
    res.end()
})

app.post("/",(req,res)=>{
    res.write("First Post Request")
    res.end();
})

app.put("/",(req,res)=>{
    res.write("First Put Request")
    res.end();
})

app.delete("/",(req,res)=>{
    res.write("First Delete Request")
    res.end();
})
app.listen(3000,()=>{
    console.log("Server Started....")
})
