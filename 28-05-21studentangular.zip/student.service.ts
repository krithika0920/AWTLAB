import { Injectable } from '@angular/core';
import {Student} from './student'
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  students:Student[]=[
    {"rollno":1,"name":"Krithika","branch":"IT","emailId":"krithi01@gmail.com"},
    {"rollno":2,"name":"ABC","branch":"IT","emailId":"a@gmail.com"},
    {"rollno":3,"name":"BA","branch":"IT","emailId":"b@gmail.com"},
    {"rollno":4,"name":"ca","branch":"IT","emailId":"c@gmail.com"},
    {"rollno":5,"name":"db","branch":"IT","emailId":"d@gmail.com"},
    {"rollno":6,"name":"er","branch":"IT","emailId":"e@gmail.com"}

  ]
  public getStudents(){
    return this.students;
  }
  public addStudent(student:Student){
    this.students.push(student)
  }
  public deleteStudent(i:any){
    this.students.splice(i,1)
  }
  constructor() { }
}