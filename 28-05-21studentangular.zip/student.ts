export class Student{
    rollno:Number;
    name:String;
    branch:String;
    emailId:String;
    constructor(id:Number,name:String,branch:String,email:String){
        this.rollno=id;
        this.name=name;
        this.branch=branch;
        this.emailId=email;
    }
}