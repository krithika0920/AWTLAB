import { Component } from '@angular/core';
import {Student} from './student';
import { StudentService } from './student.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lab';
  rollno:Number=0;
  name:String="";
  branch:String="";
  emailId:String="";
  studentService;
  student:any;
  showme:boolean=false;
  constructor(){
    this.studentService=new StudentService();
  }
  students:Student[]=[]
  getStudents(){
    this.students=this.studentService.getStudents()
  }
  addStudent(){
    this.student=new Student(this.rollno,this.name,this.branch,this.emailId)
    this.studentService.addStudent(this.student);
    this.rollno=0;
    this.branch="";
    this.name="";
    this.emailId="";
  }
  deleteStudent(i:Number){
    this.studentService.deleteStudent(i);
  }
}